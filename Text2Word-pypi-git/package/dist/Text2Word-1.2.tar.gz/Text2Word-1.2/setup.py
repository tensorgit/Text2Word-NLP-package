# TODO: Fill out this file with information about your package

# HINT: Go back to the object-oriented programming lesson "Putting Code on PyPi" and "Exercise: Upload to PyPi"

# HINT: Here is an example of a setup.py file
# https://packaging.python.org/tutorials/packaging-projects/
from setuptools import setup

setup(name='Text2Word',
      version='1.2',
      description='',
      packages=['Text2Word'],
      author = 'Jasvir Dhillon',
      author_email = 'jasvirsingh535@gmail.com',
      zip_safe=False)