import nltk
from nltk.corpus import stopwords
from nltk.stem.porter import *
import re
from bs4 import BeautifulSoup
import numpy as np


class perform:
    """ Gaussian distribution class for calculating and 
	visualizing a Gaussian distribution.
	
	Attributes:
		mean (float) representing the mean value of the distribution
		stdev (float) representing the standard deviation of the distribution
		data_list (list of floats) a list of floats extracted from the data file
			
	"""
    
    def __init__(self):
        
    
    def review_to_words(review):
        """Function to clean a unit text using 'nltk'. For ex. a restaurant review.
        - removes html tags
        - converts all to lowercase
        - applies word stemming
        - splits text string into individual words
        - removes stopwords (words that do not affect sentiment of the text)
				
		Args:
			review (string): a single review
		
		Returns:
			list of cleaned words out of the input text review
		"""
        
        nltk.download("stopwords", quiet=True)
        stemmer = PorterStemmer()
        text = BeautifulSoup(review, "html.parser").get_text() # Remove HTML tags
        text = re.sub(r"[^a-zA-Z0-9]", " ", text.lower()) # Convert to lower case
        words = text.split() # Split string into words
        words = [w for w in words if w not in stopwords.words("english")] # Remove stopwords
        words = [PorterStemmer().stem(w) for w in words] # stem
    
        return words
        
    
    def preprocess_data(data_train, data_test):
        """Function to read in data from a txt file. The txt file should have
		one number (float) per line. The numbers are stored in the data attribute.
				
		Args:
			data_train (list): training data (text strings) stored as a list
            data_test (list): test data (text strings) stored as a list
		
		Returns:
			words_train (list): each training data text converted to list of cleaned
            words using the 'review_to_words' function stored within a list
            words_test (list): each test data text converted to list of cleaned
            words using the 'review_to_words' function stored within a list
		"""
        
        words_train = [review_to_words(review) for review in data_train]
        words_test = [review_to_words(review) for review in data_test]
        
    def word_dict():
        """Function to read in data from a txt file. The txt file should have
		one number (float) per line. The numbers are stored in the data attribute.
				
		Args:
			file_name (string): name of a file to read from
		
		Returns:
			None
		"""
        
    
    def BoW():
        """Function to read in data from a txt file. The txt file should have
		one number (float) per line. The numbers are stored in the data attribute.
				
		Args:
			file_name (string): name of a file to read from
		
		Returns:
			None
		"""
        
        
        